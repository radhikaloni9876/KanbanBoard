import './KanbanCard.css';
import React from "react";

const KanbanCard = ({ ticket }) => {
  return (
    <div className="kanban-card">
      <h4>{ticket.id}</h4>
      <p>{ticket.title}</p>
      <div className="tags">
        {ticket.tag.map((tag, index) => (
          <span key={index} className="tag">
            {tag}
          </span>
        ))}
      </div>
      <p>
        <strong>Priority:</strong> {ticket.priority}
      </p>
      
      {/* Feature Request section */}
      {ticket.isFeatureRequest && (
        <div className="feature-request">
          <span className="bullet"></span>
          <span>Feature Request</span>
        </div>
      )}
    </div>
  );
};

export default KanbanCard;





