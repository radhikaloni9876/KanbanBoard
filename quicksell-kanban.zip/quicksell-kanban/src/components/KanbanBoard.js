import './KanbanBoard.css';
import React, { useEffect, useState } from "react";
import { fetchTickets } from "../utils/api";
import { groupTickets } from "./helpers";
import Header from "./Header";
import KanbanColumn from "./KanbanColumn";

const KanbanBoard = () => {
  const [tickets, setTickets] = useState([]);
  const [users, setUsers] = useState([]);
  const [groupedTickets, setGroupedTickets] = useState({});
  const [grouping, setGrouping] = useState("status");
  const [sorting, setSorting] = useState("priority");

  // Fetch data from the API
  useEffect(() => {
    const fetchData = async () => {
      const data = await fetchTickets();
      setTickets(data.tickets);
      setUsers(data.users); // Store user data
    };
    fetchData();
  }, []);

  // Create user mapping (userId -> userName)
  const userMapping = React.useMemo(() => {
    const mapping = {};
    users.forEach((user) => {
      mapping[user.id] = user.name; // Assume id and name exist in the user object
    });
    return mapping;
  }, [users]);

  // Group tickets dynamically based on the selected grouping
  useEffect(() => {
    let grouped = {};
    if (grouping === "status") {
      grouped = groupTickets(tickets, "status");
    } else if (grouping === "user") {
      grouped = groupTickets(tickets, "userId");
      // Replace userId with userName
      grouped = Object.fromEntries(
        Object.entries(grouped).map(([userId, tickets]) => [
          userMapping[userId] || "Unknown User",
          tickets,
        ])
      );
    } else if (grouping === "priority") {
      grouped = groupTickets(tickets, "priority");
    }
    setGroupedTickets(grouped);
  }, [tickets, grouping, userMapping]);

  // Sort tickets within each group
  const sortTickets = (group) => {
    if (sorting === "priority") {
      const priorityOrder = {
        "No Priority": 0,
        "Low": 1,
        "Medium": 2,
        "High": 3,
        "Urgent": 4,
      };
      return group.sort((a, b) => priorityOrder[b.priority] - priorityOrder[a.priority]);
    } else if (sorting === "title") {
      return group.sort((a, b) => a.title.localeCompare(b.title));
    }
    return group;
  };

  // Priority labels map for display
  const priorityLabels = {
    "0": "No Priority",
    "1": "Low",
    "2": "Medium",
    "3": "High",
    "4": "Urgent",
  };

  return (
    <div className="kanban-container">
      <Header
        grouping={grouping}
        setGrouping={setGrouping}
        sorting={sorting}
        setSorting={setSorting}
      />
      <div className="kanban-board">
        {Object.entries(groupedTickets).map(([group, tickets]) => {
          // Ensure the group is a string (to match the priorityLabels keys)
          const groupString = String(group);

          // Get the display group label from the priorityLabels map
          const displayGroup = grouping === "priority" 
            ? priorityLabels[groupString] || "No Priority" // Use the value if found or default to "No Priority"
            : group;

          return (
            <KanbanColumn
              key={group}
              group={displayGroup}
              ticketCount={tickets.length}
              tickets={sortTickets(tickets)}
            />
          );
        })}
      </div>
    </div>
  );
};

export default KanbanBoard;














     





 

 