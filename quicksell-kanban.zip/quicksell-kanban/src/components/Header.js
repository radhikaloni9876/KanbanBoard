import './Header.css';
import React, { useState } from "react";

const Header = ({ grouping, setGrouping, sorting, setSorting }) => {
  const [showDropdown, setShowDropdown] = useState(false);

  const handleDropdownToggle = () => {
    setShowDropdown((prev) => !prev);
  };

  return (
    <div className="header">
      <div className="display-container">
        <button className="display-button" onClick={handleDropdownToggle}>
          Display
        </button>
        {showDropdown && (
          <div className="dropdown-menu">
            {/* Grouping Section */}
            <div className="dropdown-section">
              <h4>Grouping</h4>
              <select
                value={grouping}
                onChange={(e) => setGrouping(e.target.value)}
              >
                <option value="status">Status</option>
                <option value="user">User</option>
                <option value="priority">Priority</option>
              </select>
            </div>

            {/* Ordering Section */}
            <div className="dropdown-section">
              <h4>Ordering</h4>
              <select
                value={sorting}
                onChange={(e) => setSorting(e.target.value)}
              >
                <option value="priority">Priority</option>
                <option value="title">Title</option>
              </select>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Header;




