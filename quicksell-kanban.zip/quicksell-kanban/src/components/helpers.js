export function groupTickets(tickets, groupBy, users = []) {
    if (!Array.isArray(tickets)) {
      console.error("groupTickets error: tickets is not an array", tickets);
      return {};
    }
  
    // Create a map for users to find names by userId
    const userMap = users.reduce((map, user) => {
      map[user.id] = user.name;
      return map;
    }, {});
  
    return tickets.reduce((groups, ticket) => {
      let key = ticket[groupBy] || "Unknown"; // Default to "Unknown" if no value
  
      // Custom status mapping for groupBy "status"
      if (groupBy === "status") {
        if (key === "") key = "Todo"; // Default empty status to Todo
        if (key === "in_progress") key = "In Progress";
        if (key === "done") key = "Done";
        if (key === "cancelled") key = "Cancelled";
      }
  
      // Customize keys for better readability
      if (groupBy === "user") {
        key = userMap[ticket.userId] || "Unknown User";
      }
      if (groupBy === "priority" && key === "") key = "No Priority";
  
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(ticket);
      return groups;
    }, {});
  }
  
  
  
  
  
  